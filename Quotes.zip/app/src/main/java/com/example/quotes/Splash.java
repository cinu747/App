package com.example.quotes;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import java.util.Timer;
import java.util.TimerTask;
public class Splash extends AppCompatActivity {
    Timer timer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Set the content view for the splash activity
        setContentView(R.layout.activity_splash);

        // Initialize the timer
        timer = new Timer();

        // Schedule a task to run after 5 seconds
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                // Create an intent to start the QuoteReaderActivity
                Intent intent = new Intent(Splash.this, QuoteReaderActivity.class);

                // Start the QuoteReaderActivity
                startActivity(intent);

                // Finish the current activity to prevent returning to the splash screen
                finish();
            }
        }, 5000); // 5000 milliseconds (5 seconds) delay before executing the task
    }
}
