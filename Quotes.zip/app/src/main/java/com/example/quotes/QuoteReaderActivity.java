/*
Name: Cini Kolath Abraham
Lab 3
Brief program description: This code is to create a ListView full of quotes in the
first screen and then when the user clicks on a particular quote they will be taken
 to a detail view of the full quote. A splash screen is incorporated, presenting for a
 duration of 5 seconds before transitioning to the main page */

package com.example.quotes;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.content.Context;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ListView;

public class QuoteReaderActivity extends AppCompatActivity {
    public class QuoteAdapter extends BaseAdapter {
        private Context mContext;
        private LayoutInflater mInflator;
        private DataSource mDataSource;

        public QuoteAdapter(Context c) {
            mContext = c;
            mInflator = (LayoutInflater)
                    mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            mDataSource = new DataSource();
        }

        @Override
        public int getCount() {
            return mDataSource.getDataSourceLength();
        }

        @Override
        public Object getItem(int position) {
            // Return the data item at the specified position
            return position;
        }

        @Override
        public long getItemId(int position) {
            // Return the row id associated with the specified position
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            // Declare ImageView and TextView for each item in the ListView
            ImageView thumbnail;
            TextView quote;

            // If the convertView is null, inflate the layout for the list item
            if (convertView == null) {
                convertView = mInflator.inflate(R.layout.list_item_layout, parent, false);
            }

            // Find the ImageView in the list item layout
            thumbnail = convertView.findViewById(R.id.thumb);

            // Set the image resource for the ImageView using the photo pool in DataSource
            thumbnail.setImageResource(mDataSource.getmPhotoPool().get(position));

            // Find the TextView in the list item layout
            quote = convertView.findViewById(R.id.text);

            // Set the text for the TextView using the quote pool in DataSource
            quote.setText(mDataSource.getmQuotePool().get(position));

            // Return the populated convertView
            return convertView;
        }

    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quote_reader);

        // Find the ListView
        ListView mListView = findViewById(R.id.quotes_list);
        mListView.setAdapter(new QuoteAdapter(this));

        // Check if the ListView is not null
        if (mListView != null) {
            // Set your adapter here (replace `yourAdapter` with your actual adapter)
            // Example: listView.setAdapter(yourAdapter);
        } else {
            System.out.println("QuoteReaderActivity: ListView is null");
        }
        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView arg0, View arg1, int
                    position,long arg3) {
                Intent i = new Intent(QuoteReaderActivity.this,
                        QuoteDetail.class);
                i.putExtra("position", position);
                startActivity(i);
            }
        });


    }
}