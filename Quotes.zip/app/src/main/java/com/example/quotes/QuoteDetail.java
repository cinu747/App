package com.example.quotes;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class QuoteDetail extends AppCompatActivity {
    private ImageView mImageView;
    private TextView mQuote;
    private int mPosition;
    private DataSource mDataSource;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Set the content view for the activity
        setContentView(R.layout.quote_detail);

        // Get the intent that started this activity
        Intent i = getIntent();

        // Get the position value from the intent, default to 0 if not found
        mPosition = i.getIntExtra("position", 0);

        // Create a new instance of the DataSource class
        mDataSource = new DataSource();

        // Initialize the ImageView and TextView by finding their respective views in the layout
        mImageView = findViewById(R.id.image);
        mQuote = findViewById(R.id.quote);

        // Set the image resource for the ImageView using the photo pool in DataSource
        mImageView.setImageResource(mDataSource.getmPhotoHdPool().get(mPosition));

        // Set the text for the TextView using the quote pool in DataSource
        mQuote.setText(getResources().getString(mDataSource.getmQuotePool().get(mPosition)));
    }
}
