/*
Name: Cini Kolath Abraham
Lab 5
Brief program description: This application is a quiz with 5 questions which includes true/false radio options.
An image button is added for the user to navigate to the next question. The correct response will be shown by
shaded stars at the end of the quiz. Time elapsed is also shown upon display. The questions are randomized and
hence the user will get different startup questions each time.*/

package com.example.quiz;
import androidx.appcompat.app.AppCompatActivity;
import android.os.AsyncTask;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import android.os.Bundle;
import java.io.BufferedReader;
import java.io.InputStream;

public class MainActivity extends AppCompatActivity {

    TextView txtView;
    List<String> stringList = new ArrayList<>();


    static int questionNum = 0;

    private RadioGroup radioQuestions;
    private RadioButton radioButton;

    ImageView image;
    int starcount = 0;
    private long startTime;
    private long endTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BackgroundTask bt = new BackgroundTask();
        bt.execute("http://www.papademas.net:81/sample.txt"); 
        RatingBar rb = findViewById(R.id.ratingBar);
        rb.setRating(starcount);
        rb.setVisibility(View.INVISIBLE);
        startTime = System.currentTimeMillis();

    }//end onCreate

    //background process to download the file from internet
    private class BackgroundTask extends AsyncTask<String, Integer, Void> {

        protected void onPreExecute() {  }

        protected Void doInBackground(String... params) {
            URL url;
            String StringBuffer = null;
            try {
                //create url object to point to the file location on internet
                url = new URL(params[0]);
                //make a request to server
                HttpURLConnection con = (HttpURLConnection) url.openConnection();
                //get InputStream instance
                InputStream is = con.getInputStream();
                //create BufferedReader object
                BufferedReader br = new BufferedReader(new InputStreamReader(is));

                //read content of the file line by line & add it to Stringbuffer
                while ((StringBuffer = br.readLine()) != null) {
                    stringList.add(StringBuffer);  //add to Arraylist
                }

                br.close();

            } catch (Exception e) {
                e.printStackTrace();
            }

            return null;
        }

        protected void onPostExecute(Void result) {
            txtView = findViewById(R.id.textView1);
            Collections.shuffle(stringList);
            //display read text in TextVeiw
            txtView.setText(stringList.get(0));
            startQuiz();
        }
    }//end BackgroundTask class

    public void startQuiz() {
        buttonListener();
    }

    public void buttonListener() {

        Button btnDisplay;

        radioQuestions = findViewById(R.id.radioQuestions);
        btnDisplay = findViewById(R.id.btnDisplay);

        btnDisplay.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {

                // get selected radio button from radioGroup
                int selectedId = radioQuestions.getCheckedRadioButtonId();

                // find the radiobutton by returned id
                radioButton = findViewById(selectedId);

                switch (questionNum) {
                    case 0:
                    case 2:
                        //verify if result matches the right button selection
                        //i.e., (True or false!)
                        if (radioButton.getText().equals("True")) {
                            Toast.makeText(MainActivity.this,
                                    " Right!", Toast.LENGTH_LONG).show();
                            starcount++;
                        }
                        else
                            Toast.makeText(MainActivity.this,
                                    " Wrong!", Toast.LENGTH_LONG).show();
                        break;
                    case 1:
                        //verify if result matches the right button selection
                        //i.e., (True or false!)
                        if (radioButton.getText().equals("False")){
                            Toast.makeText(MainActivity.this,
                                    " Right!", Toast.LENGTH_LONG).show();
                            starcount++;
                        }
                        else
                            Toast.makeText(MainActivity.this,
                                    " Wrong!", Toast.LENGTH_LONG).show();
                        break;
                    case 3:
                        //verify if result matches the right button selection
                        //i.e., (True or false!)
                        if (radioButton.getText().equals("True")){
                            Toast.makeText(MainActivity.this,
                                    " Right!", Toast.LENGTH_SHORT).show();
                            starcount++;
                        }
                        else
                            Toast.makeText(MainActivity.this,
                                    " Wrong!", Toast.LENGTH_SHORT).show();
                        break;
                    case 4:
                        if (radioButton.getText().equals("False")){
                            Toast.makeText(MainActivity.this,
                                    " Right!", Toast.LENGTH_SHORT).show();
                            starcount++;
                        }
                        else
                            Toast.makeText(MainActivity.this,
                                    " Wrong!", Toast.LENGTH_SHORT).show();
                        break;
                }//end switch
                System.out.println("Count = " +starcount);
            }
        });
        imageListener();
    }//end buttonListener

    public void imageListener() {
        image = findViewById(R.id.imageView1);
        image.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                RatingBar rb = findViewById(R.id.ratingBar);

                // Check if there are more questions available
                if (questionNum < stringList.size() - 1) {
                    // Increment questionNum only if there are more questions
                    questionNum++;
                    txtView.setText(stringList.get(questionNum));
                    // Reset radio button to default
                    radioQuestions.check(R.id.radioTrue);
                } else {
                    rb.setVisibility(View.VISIBLE);
                    rb.setRating(starcount);
                    endTime = System.currentTimeMillis();
                    long elapsedMillis = endTime - startTime;

                    // Convert milliseconds to seconds
                    float elapsedSeconds = elapsedMillis / 1000f;
                    Toast.makeText(MainActivity.this,
                            " You took " + elapsedSeconds + " seconds", Toast.LENGTH_LONG).show();
                    System.out.println("You took " + elapsedSeconds + " seconds to complete the quiz");
                    // Reset count to -1 to start the first question again
                    questionNum = -1;
                }
            }
        });
    }

}
